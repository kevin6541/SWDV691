import pymysql
from app import app
import flask
from config import mysql
from flask import jsonify
from flask import flash, request
import simplejson

app.config["DEBUG"] = True###restarts server with each save

@app.route('/', methods=['GET'])
def home():
    all_rows = session.query('Products').all()#to make decimals work with json
    response = simplejson.dumps(all_rows)
    return '''<h1>WebStore Database</h1>
            <p>API Testing</p>'''


####MIGHT ADD ALTER TABLE TO CREATE NEW FIELDS############

###CREATE###
######ADD CUSTOMER BY JSON - AS MANY AS NEEDED#############
@app.route('/api/cust/add', methods=['POST'])
def add_cust():
    _cust = request.json
    for _json in _cust:
        _name = _json['fName']
        _lname = _json['lName']
        _address = _json['address']
        _phone = _json['phone']
        _username = _json['username']
        _password = _json['password']
        _address2 = _json['address2']
        _address3 = _json['address3']
        _phone2 = _json['phone2']
        if request.method == 'POST':
            sqlQuery = "INSERT INTO Customers(fName,lName,address,phone, \
                        username, password, address2, address3, phone2) \
                        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            bindData = (_name, _lname, _address, _phone, _username, \
                        _password, _address2, _address3, _phone2)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Customer added successfully!')
            response.status_code = 200
    return response
    
######ADD PRODUCT BY JSON - AS MANY AS NEEDED#############
@app.route('/api/products/add', methods=['POST'])
def add_prod():
    _prod = request.json
    for _json in _prod:
        _name = _json['prodName']
        _price = _json['price']
        _file = _json['imageFile']
        _desc = _json['description']
        if request.method == 'POST':
            sqlQuery = "INSERT INTO Products(prodName,price,imageFile,description) \
                            VALUES(%s,%s,%s,%s)"
            bindData = (_name, _price, _file, _desc)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Product added successfully!')
            response.status_code = 200
    return response

######ADD CART BY JSON - AS MANY AS NEEDED#############
@app.route('/api/carts/add', methods=['POST'])
def add_cart():####dateCreated and state have default values
    _json = request.json
    for _cart in _json:
        _custID = _cart['CustID']
        if request.method == 'POST':
            sqlQuery = "INSERT INTO Cart(CustID) VALUES(%s)"
            bindData = (_custID)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Cart added successfully!')
            response.status_code = 200
    return response

######ADD CARTITEM BY JSON - AS MANY AS NEEDED#############
@app.route('/api/cartitems/add', methods=['POST'])
def add_cartitem():
    _json = request.json
    for _cart in _json:
        _prodID = _cart['prodID']
        _custID = _cart['custid']
        _qty = _cart['qty']
        if request.method == 'POST':
            sqlQuery = "INSERT INTO CartItems(prodID, custid, qty) VALUES(%s,%s,%s)"
            bindData = (_prodID, _custID, _qty)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Cart items added successfully!')
            response.status_code = 200
    return response

####READ#####
########GET ALL CUST######
@app.route('/api/cust/all', methods=['GET'])
def get_all():
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM Customers;')
    custRows = cur.fetchall()
    response = jsonify(custRows)
    response.status_code = 200
    return response
########GET ALL PRODUCTS######
@app.route('/api/products/all', methods=['GET'])
def get_all_prod():
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM Products;')
    custRows = cur.fetchall()
    response = jsonify(custRows)
    response.status_code = 200
    return response
########GET ALL CARTS######
@app.route('/api/carts/all', methods=['GET'])
def get_all_carts():
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM Cart;')
    custRows = cur.fetchall()
    response = jsonify(custRows)
    response.status_code = 200
    return response
########GET ALL CARTITEMS######
@app.route('/api/cartitems/all', methods=['GET'])
def get_all_cartitems():
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM CartItems;')
    custRows = cur.fetchall()
    response = jsonify(custRows)
    response.status_code = 200
    return response

######GET BY CUST ID#############
@app.route('/api/cust/<int:id>')      
def getCust_byId(id):
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM Customers WHERE CustID =%s', id)
    custRows = cur.fetchone()
    response = jsonify(custRows)
    response.status_code = 200
    return response
######GET BY PRODUCT ID#############
@app.route('/api/products/<int:id>')      
def get_prod_id(id):
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute('SELECT * FROM Products WHERE ProdID =%s;', id)
    custRows = cur.fetchone()
    response = jsonify(custRows)
    response.status_code = 200
    return response
######GET CART BY CUST ID#############
#####calculates the total sale based on product price and qty, no tax included yet
#####basically creates a view of the cart and the total price given the custid
@app.route('/api/cart/view/<int:custID>')      
def get_cart_id(custID):
    sqlQuery = "SELECT * FROM (SELECT fname, lname FROM Customers WHERE custID={0}) AS A \
                JOIN (SELECT * FROM Cart WHERE CustID={0}) AS B \
                JOIN (SELECT SUM(qty * price) AS Total FROM Products AS p \
                INNER JOIN CartItems AS c ON p.ProdID=c.ProdID WHERE CustID={0}) AS C;".format(custID)
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute( sqlQuery)
    custRows = cur.fetchone()
    response = jsonify(custRows)
    response.status_code = 200
    return response
######GET CARTITEMS BY CUST ID############
@app.route('/api/cartitems/<int:custid>')      
def get_cartitems_id(custid):
    conn = mysql.connect()
    cur = conn.cursor(pymysql.cursors.DictCursor)
    sqlQuery = "SELECT * FROM cartitems WHERE custid=%s;"
    cur.execute(sqlQuery, custid)
    custRows = cur.fetchall()
    response = jsonify(custRows)
    response.status_code = 200
    return response

###UPDATE#####    
######UPDATE CUSTOMER BY JSON - WORKS FOR MULTIPLES#############
@app.route('/api/cust/update', methods=['PUT'])
def update_cust():
    _json = request.json
    for _custs in _json:
        _id = _custs['CustID']
        _name = _custs['fName']
        _lname = _custs['lName']
        _address = _custs['address']
        _phone = _custs['phone']
        _username = _custs['username']
        _password = _custs['password']
        _address2 = _custs['address2']
        _address3 = _custs['address3']
        _phone2 = _custs['phone2']
        if request.method == 'PUT':
            sqlQuery = "UPDATE Customers SET fName=%s, lName=%s, \
                        address=%s, phone=%s, username=%s, password=%s, \
                        address2=%s, address3=%s, phone2=%s WHERE CustID=%s"
            bindData = (_name, _lname, _address, _phone, _username, \
                        _password, _address2, _address3, _phone2, _id)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Customer Table updated successfully!')
            response.status_code = 200
    return response
    
######NEVER UPDATE/DELETE PRODUCTS B/C CARTS/ORDERS WILL BE ALTERED - exception for image file names, 
                        ##however maybe just make new images the same file name as the old image#############

######UPDATE CART STATE BY JSON - WORKS FOR MULTIPLES#############
@app.route('/api/cart/update', methods=['PUT'])
def update_cart():
    _json = request.json
    for _cart in _json:
        _cartid = _cart['CartID']
        _state = _cart['state']
        if request.method == 'PUT':
            sqlQuery = "UPDATE Cart SET state=%s WHERE CartID=%s"
            bindData = (_state, _cartid)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Cart updated successfully!')
            response.status_code = 200
    return response  

######UPDATE PRODUCTS BY JSON - WORKS FOR MULTIPLES#############
@app.route('/api/products/update', methods=['PUT'])
def update_prods():
    _json = request.json
    for _prod in _json:
        _prodid = _prod['prodID']
        _desc = _prod['description']
        _img = _prod['imageFile']
        _price = _prod['price']
        _name = _prod['prodName']
        _quant = _prod['qty']
        if request.method == 'PUT':
            sqlQuery = "UPDATE Products SET description=%s, imageFile=%s, \
                         price=%s, prodName=%s, qty=%s WHERE prodID=%s"
            bindData = (_desc, _img, _price, _name, _quant, _prodid)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sqlQuery, bindData)
            conn.commit()
            response = jsonify('Product updated successfully!')
            response.status_code = 200
    return response      


####DELETE####
#################DONT DELETE ANYTHING##########
######DELETE CUSTOMER BY ID IF NECESSARY############
######WILL NEED TO BE REMOVED FROM CARTS AND CART ITEMS TOO#################
###########WONT DELETE STRAIGHT OUT B/C OF THE KEY LINKS TO OTHER TABLES######
#########Only delete customers with zero activity - no other table associations#####
@app.route('/api/cust/delete/<int:id>', methods=['DELETE'])
def delete_cust(id):
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Customers WHERE CustID =%s", id)
    conn.commit()
    response = jsonify('Customer deleted successfully!')
    response.status_code = 200
    return response


@app.errorhandler(404)
def page_not_found(e):
    return "<h1>404</h1><p>The resource could not be found.</p>", 404


app.run()


