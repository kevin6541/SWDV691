from app import app
from flaskext.mysql import MySQL

mysql = MySQL()
app.config['MYSQL_DATABASE_USER'] = 'webStoreAdminUser'
app.config['MYSQL_DATABASE_PASSWORD'] = 'OBalls2012@#'
app.config['MYSQL_DATABASE_DB'] = 'WebStore'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)
