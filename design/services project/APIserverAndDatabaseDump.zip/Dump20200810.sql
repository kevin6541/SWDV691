-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: webstore
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `CartID` int NOT NULL AUTO_INCREMENT,
  `CustID` int NOT NULL,
  `dateCreated` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint(1) NOT NULL DEFAULT (0),
  PRIMARY KEY (`CartID`),
  KEY `fk_CustID_cart` (`CustID`),
  CONSTRAINT `fk_CustID_cart` FOREIGN KEY (`CustID`) REFERENCES `customers` (`CustID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,1,'2020-07-23 04:20:27',1),(2,2,'2020-07-23 05:20:35',1),(3,3,'2020-07-23 05:20:41',1),(6,5,'2020-07-24 02:07:26',0),(7,6,'2020-07-24 02:08:22',0),(8,8,'2020-07-24 04:02:23',0),(9,9,'2020-07-25 23:12:21',0),(10,10,'2020-07-25 23:12:21',0);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartitems`
--

DROP TABLE IF EXISTS `cartitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cartitems` (
  `cartItemID` int NOT NULL AUTO_INCREMENT,
  `prodID` int NOT NULL,
  `custid` int NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`cartItemID`),
  KEY `fk_prodID_cartItems` (`prodID`),
  KEY `fk_cartID_cartItems` (`custid`),
  CONSTRAINT `fk_cartID_cartItems` FOREIGN KEY (`custid`) REFERENCES `cart` (`CartID`),
  CONSTRAINT `fk_prodID_cartItems` FOREIGN KEY (`prodID`) REFERENCES `products` (`prodID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartitems`
--

LOCK TABLES `cartitems` WRITE;
/*!40000 ALTER TABLE `cartitems` DISABLE KEYS */;
INSERT INTO `cartitems` VALUES (2,1,1,3),(3,2,1,1),(4,3,1,4),(5,2,2,1),(6,1,2,1),(7,4,3,1),(8,5,6,1),(10,6,1,3),(12,4,9,3);
/*!40000 ALTER TABLE `cartitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `CustID` int NOT NULL AUTO_INCREMENT,
  `fName` varchar(20) DEFAULT NULL,
  `lName` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CustID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'kevin','smith','streets','5555555555','kusername','kpassword',NULL,NULL,NULL),(2,'someone','special','1234','1234566789','something','psswrd',NULL,NULL,NULL),(3,'someone else','but not special','1234 street st','123-456-6789','elsesomeone',NULL,NULL,NULL,NULL),(5,'noOne','Smith','4567 street rd','123-987-6543','notNullUser','notAnull',NULL,NULL,'654-235-4567'),(6,'jack','giant','4654','1345432345','beans','stalker','','',''),(8,'ellen','ripley','U.S.S Sulaco','phone#','ripley','ripspasswd','','',''),(9,'bruce','wayne','wayne manor','1-800-bmobile','batman','robin',NULL,NULL,NULL),(10,'Alfred','Pennyworth','wayne manor','1-800-bmobile','al','batcave',NULL,NULL,NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `prodID` int NOT NULL AUTO_INCREMENT,
  `prodName` varchar(255) NOT NULL,
  `price` decimal(5,2) DEFAULT NULL,
  `imageFile` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int DEFAULT NULL,
  PRIMARY KEY (`prodID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Peanut M&M\'s',1.99,'./images/mockData/peanutM&Ms.jpg','Share Size Candy (AKA - King Sized)',87),(2,'Card',4.00,'./images/mockData/B-Day Card.jpg','Bday Card',12),(3,'Card',3.99,'./images/mockData/congratsCard.jpg','Congrats Card',3),(4,'Plush',30.99,'./images/mockData/wicket.jpg','Ewok - Wicket',2),(5,'Welcome Mat',20.99,'./images/mockData/welcome mat.jpg','Rug',5),(6,'Best Dad Mug',10.99,'./images/mockData/dadMug.jpg','Coffee Mug',4),(7,'Water',1.00,'./images/mockData/water.jpg','Bottled Water',30),(8,'Blanket',8.99,'./images/mockData/blanket.jpg','Warm Blanket',2);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-10 16:11:18
